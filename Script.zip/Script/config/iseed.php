<?php

return [
    'path' => '/database/seeders',
    'chunk_size' => 500, // Maximum number of rows per insert statement
];
