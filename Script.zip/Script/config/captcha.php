<?php

return [
    // Dummy dev keys for defaults
    'secret' => '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI',
    'sitekey' => '6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe',
    'options' => [
        'timeout' => 30,
    ],
];
